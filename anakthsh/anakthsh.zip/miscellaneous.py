# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 21:07:07 2024

@author: User
"""

def from_num_to_title(doc_num, documents):
    return documents[doc_num]["title"]

